WinCE 1.00(00)

Realise the enormous power of Windows CE on your Series 5.

http://www.geocities.com/SiliconValley/Heights/5596/