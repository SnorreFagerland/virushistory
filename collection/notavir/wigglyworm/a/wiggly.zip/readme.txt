WigglyWorm 1.00(00)

Remote Link indicator for Series 5.

Uses SYSTINFO.OPX (c) Otfried Cheong

http://www.geocities.com/SiliconValley/Heights/5596/